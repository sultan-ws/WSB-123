export const Data = [
  {
    id: 1,
    year: 2000,
    userGain: 10000,
    userLoss: 2000,
  },
  {
    id: 2,
    year: 2001,
    userGain: 12000,
    userLoss: 5000,
  },
  {
    id: 3,
    year: 2002,
    userGain: 14000,
    userLoss: 1000,
  },
  {
    id: 4,
    year: 2003,
    userGain: 16000,
    userLoss: 1000,
  },
  {
    id: 5,
    year: 2004,
    userGain: 16000,
    userLoss: 2000,
  },
];
